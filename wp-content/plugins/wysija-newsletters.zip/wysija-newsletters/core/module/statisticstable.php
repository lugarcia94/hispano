<?php
defined('WYSIJA') or die('Restricted access');

abstract class WYSIJA_module_statisticstable extends WYSIJA_module_statistics{
}